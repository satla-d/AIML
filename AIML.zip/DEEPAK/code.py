import tkinter as tk
from tkinter import messagebox
import logging
import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.metrics import classification_report
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import base64
import threading
import re
import nltk
from nltk.corpus import stopwords

nltk.download('stopwords')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

# Load dataset
try:
    df = pd.read_csv(r"C:\Users\SATHVIK\Desktop\aiml\project\mail_dataset.csv")
    if 'Category' not in df.columns or 'Message' not in df.columns:
        raise ValueError("Dataset must contain 'Category' and 'Message' columns.")
    print("Column names:", df.columns)
    print("First few rows:\n", df.head())
except Exception as e:
    logger.error(f"Error loading dataset: {e}")
    raise

# Preprocess text function
def preprocess_text(text):
    stop_words = set(stopwords.words('english'))
    text = re.sub(r'\W', ' ', text)
    text = text.lower()
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

df['Message'] = df['Message'].apply(preprocess_text)

# Train test split
X_train, X_test, y_train, y_test = train_test_split(df['Message'], df['Category'], test_size=0.2, random_state=42)

# Define pipeline and grid search parameters
pipeline = make_pipeline(TfidfVectorizer(), MultinomialNB())

param_grid = {
    'tfidfvectorizer__ngram_range': [(1, 1), (1, 2)],
    'multinomialnb__alpha': [0.1, 1, 10]
}

# Grid search with reduced n_jobs
grid_search = GridSearchCV(pipeline, param_grid, cv=5, n_jobs=1, verbose=1)
grid_search.fit(X_train, y_train)

best_model = grid_search.best_estimator_

# Test the model
predictions = best_model.predict(X_test)
print(classification_report(y_test, predictions))

# Function to fetch emails using Gmail API
def fetch_emails_gmail_api():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                r'C:\Users\SATHVIK\Desktop\aiml\project\client_secret.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    try:
        service = build('gmail', 'v1', credentials=creds)
        results = service.users().messages().list(userId='me', maxResults=10, q="is:inbox").execute()
        messages = results.get('messages', [])
        
        emails = []
        for msg in messages:
            txt = service.users().messages().get(userId='me', id=msg['id']).execute()
            payload = txt['payload']
            headers = payload.get("headers")
            subject = ""
            for header in headers:
                if header['name'] == 'Subject':
                    subject = header['value']
                    break
            parts = payload.get('parts')[0]
            data = parts['body']["data"]
            body = base64.urlsafe_b64decode(data).decode("utf-8")
            emails.append({"subject": subject, "body": body})
        return pd.DataFrame(emails)
    except Exception as e:
        logger.error(f"Error fetching emails: {e}")
        return pd.DataFrame()

# GUI for spam classifier
class SpamClassifierApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Email Spam Classifier")
        self.root.geometry("600x500")
        self.root.configure(bg="#2c3e50")

        self.title_label = tk.Label(root, text="Email Spam Classifier", font=("Arial", 18, "bold"), bg="#2c3e50", fg="white")
        self.title_label.pack(pady=10)

        self.fetch_button = tk.Button(root, text="Fetch and Classify Emails", command=self.fetch_and_classify_emails, font=("Arial", 14), bg="#3498db", fg="white", activebackground="#2980b9", activeforeground="white", relief="raised", bd=3)
        self.fetch_button.pack(pady=15)

        self.label = tk.Label(root, text="Enter Email Text for Manual Classification:", font=("Arial", 14), bg="#2c3e50", fg="white")
        self.label.pack(pady=5)

        self.manual_text_entry = tk.Text(root, height=5, width=50, font=("Arial", 12), bd=2, relief="solid", wrap="word")
        self.manual_text_entry.pack(pady=5, padx=20)

        self.classify_button = tk.Button(root, text="Classify Manually", command=self.classify_manual_email, font=("Arial", 14), bg="#3498db", fg="white", activebackground="#2980b9", activeforeground="white", relief="raised", bd=3)
        self.classify_button.pack(pady=15)

        self.result_label = tk.Label(root, text="", font=("Arial", 14, "bold"), bg="#2c3e50", fg="white")
        self.result_label.pack(pady=10)

        self.classified_emails_text = tk.Text(root, height=10, width=70, font=("Arial", 12), bd=2, relief="solid", wrap="word")
        self.classified_emails_text.pack(pady=10, padx=20)

    def fetch_and_classify_emails(self):
        threading.Thread(target=self.fetch_and_classify).start()

    def fetch_and_classify(self):
        df_emails = fetch_emails_gmail_api()
        if df_emails.empty:
            messagebox.showinfo("No Emails", "No emails found in the inbox.")
            return

        df_emails['body'] = df_emails['body'].apply(preprocess_text)
        predictions = best_model.predict(df_emails['body'])
        df_emails['label'] = predictions

        self.classified_emails_text.delete(1.0, tk.END)
        for index, row in df_emails.iterrows():
            result_line = f"Subject: {row['subject']} - Prediction: {'Spam' if row['label'] == 'spam' else 'Not Spam'}\n"
            self.classified_emails_text.insert(tk.END, result_line)

    def classify_manual_email(self):
        email_text = self.manual_text_entry.get("1.0", "end-1c")
        if not email_text.strip():
            messagebox.showwarning("Input Error", "Please enter the email text.")
            return

        email_text = preprocess_text(email_text)
        prediction = best_model.predict([email_text])[0]
        result = "Spam" if prediction == "spam" else "Not Spam"
        self.result_label.config(text=f"Prediction: {result}", fg="#e74c3c" if result == "Spam" else "#2ecc71")

# Run the app
root = tk.Tk()
app = SpamClassifierApp(root)
root.mainloop()
